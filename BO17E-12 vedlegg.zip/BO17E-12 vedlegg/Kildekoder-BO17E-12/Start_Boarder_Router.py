import os, sys
import shutil
from subprocess import call
import time
import fnmatch
import glob, re
import time

print "\nStarter BR kanal 1\n"
cmd = 'ssh -l root 10.8.0.18 ./root/contiki/tools/tunslip6  aaaa:1/64 -s /dev/ttyS1 > /dev/null 2>&1 & disown' #Starter debug logging paa serialport
call(cmd.split())
print "\nStarter BR kanal 2\n"
cmd = 'ssh -l root 10.8.0.18 ./root/contiki/tools/tunslip6  aaaa:1/64 -s /dev/ttyS2 > /dev/null 2>&1 & disown' #Starter debug logging paa serialport
call(cmd.split())
print "\nStarter BR kanal 3\n"
cmd = 'ssh -l root 10.8.0.18 ./root/contiki/tools/tunslip6  aaaa:1/64 -s /dev/ttyS3 > /dev/null 2>&1 & disown' #Starter debug logging paa serialport
call(cmd.split())